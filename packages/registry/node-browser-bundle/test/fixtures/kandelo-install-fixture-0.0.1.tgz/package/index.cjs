module.exports={answer:42,kind:'ordinary-js-package'};
