require('node:fs').writeFileSync('installed.marker',"real-npm-lifecycle\n");
